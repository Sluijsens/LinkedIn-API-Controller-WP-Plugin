<?php

_e( "Nice Email template. When you see this it works", "liac" );